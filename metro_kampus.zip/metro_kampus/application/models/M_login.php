<?php
class M_login extends CI_Model{

	public function cek_admin($u, $p){
		return $this->db->get_where('data_login', array('username'=>$u, 'password'=>$p));
	}



//===========================================================
	// Fungsi Untuk kamar Tidur
	public function get_tidur(){
        return $this->db->get('kamar_tidur');
    }

	public function insert_tidur($data){
		$this->db->insert('kamar_tidur',$data);
	}

	public function update_tidur($data,$kode_tidur){
		$this->db->where('kode_tidur',$kode_tidur);
		$this->db->update('kamar_tidur',$data);
	}
	public function get_data_by_kdtidur($kode_tidur){
		return $this->db->get_where('kamar_tidur',array('kode_tidur'=>$kode_tidur));
	}

	public function hapus_tidur($kode_tidur){
		$this->db->where('kode_tidur',$kode_tidur);
		$this->db->delete('kamar_tidur');
	}
				


//===========================================================
	// Fungsi Untuk Perlengkapan Belajar
	public function get_belajar(){
        return $this->db->get('perlengkapan_belajar');
    }

	public function insert_belajar($data){
		$this->db->insert('perlengkapan_belajar',$data);
	}

	public function update_belajar($data,$kode_belajar){
		$this->db->where('kode_belajar',$kode_belajar);
		$this->db->update('perlengkapan_belajar',$data);
	}
	public function get_data_by_kdbelajar($kode_belajar){
		return $this->db->get_where('perlengkapan_belajar',array('kode_belajar'=>$kode_belajar));
	}

	public function hapus_belajar($kode_belajar){
		$this->db->where('kode_belajar',$kode_belajar);
		$this->db->delete('perlengkapan_belajar');
	}
			



//===========================================================
	// Fungsi Untuk Perlengkapan Elektronik
	public function get_elektronik(){
        return $this->db->get('elektronik');
    }

	public function insert_elektronik($data){
		$this->db->insert('elektronik',$data);
	}

	public function update_elektronik($data,$kode_elektronik){
		$this->db->where('kode_elektronik',$kode_elektronik);
		$this->db->update('elektronik',$data);
	}
	public function get_data_by_kdelektronik($kode_elektronik){
		return $this->db->get_where('elektronik',array('kode_elektronik'=>$kode_elektronik));
	}
	
	public function hapus_elektronik($kode_elektronik){
		$this->db->where('kode_elektronik',$kode_elektronik);
		$this->db->delete('elektronik');
	}
				


//===========================================================
	// Fungsi Untuk Perlengkapan Dapur
	public function get_dapur(){
        return $this->db->get('dapur');
    }

	public function insert_dapur($data){
		$this->db->insert('dapur',$data);
	}

	public function update_dapur($data,$kode_dapur){
		$this->db->where('kode_dapur',$kode_dapur);
		$this->db->update('dapur',$data);
	}
	public function get_data_by_kddapur($kode_dapur){
		return $this->db->get_where('dapur',array('kode_dapur'=>$kode_dapur));
	}

	public function hapus_dapur($kode_dapur){
		$this->db->where('kode_dapur',$kode_dapur);
		$this->db->delete('dapur');
	}
				



//===========================================================
	// Fungsi Untuk Perlengkapan Mandi
	public function get_mandi(){
        return $this->db->get('kamar_mandi');
    }

	public function insert_mandi($data){
		$this->db->insert('kamar_mandi',$data);
	}

	public function update_mandi($data,$kode_mandi){
		$this->db->where('kode_mandi',$kode_mandi);
		$this->db->update('kamar_mandi',$data);
	}
	public function get_data_by_kdmandi($kode_mandi){
		return $this->db->get_where('kamar_mandi',array('kode_mandi'=>$kode_mandi));
	}
	
	public function hapus_mandi($kode_mandi){
		$this->db->where('kode_mandi',$kode_mandi);
		$this->db->delete('kamar_mandi');
	}
			



}