<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller
{

	function __construct(){
		parent::__construct();
		$this->load->model('M_login');
	}
	
	public function index()
	{
		$this->load->view('auth/login');
	}
	
	public function welcome(){
       
        $this->load->view('auth/welcome');

    }



	public function aksi_login()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		$cek = $this->M_login->cek_admin($username, $password)->num_rows();
		if ($cek > 0) {
			$data_session = array(
				'nama' => $username,
				'status' => "login"
			);

			$this->session->set_userdata($data_session);
			redirect('Auth/welcome');
		} else {
			echo "Username dan Password salah!!";
		}
	}



//========================================================================================
// Fungsi untuk data kamar Tidur
public function tidur(){
       
	$data['produk'] = $this->M_login->get_tidur()->result_array();
	$this->load->view('auth/main_tidur',$data);

}

	public function tambah_tidur(){
        $this->load->view('auth/form_tambahtidur');
    }
    public function aksi_simpan_tidur(){
        $kode_tidur=$this->input->post('kode_tidur');
		$kategori_tidur=$this->input->post('kategori_tidur');
		$merk_tidur=$this->input->post('merk_tidur');
		$keterangan_tidur=$this->input->post('keterangan_tidur');
		$harga_tidur=$this->input->post('harga_tidur');
		$gambar_tidur=$_FILES['gambar_tidur'];
	
			$config['upload_path'] = './assets/upload';
			$config['allowed_types'] = 'jpg|png|gif';

			$this->load->library('upload', $config);

			if(!$this->upload->do_upload('gambar_tidur')){
				echo "Upload Gagal"; die();
			}else{
				$gambar_tidur=$this->upload->data('file_name');
			}
		

		$data=array(
		'kode_tidur'=>$kode_tidur,
		'kategori_tidur'=>$kategori_tidur,
		'merk_tidur'=>$merk_tidur,
		'keterangan_tidur'=>$keterangan_tidur,
		'harga_tidur'=>$harga_tidur,
		'gambar_tidur'=>$gambar_tidur,
		);
        $this->M_login->insert_tidur($data);
    if($this->db->affected_rows()){
        redirect('auth/tidur');
    } else {
        redirect('auth/tambah_tidur');
    }  
 }

	public function edit_tidur($kode_tidur){
		$data['produk'] = $this->M_login->get_data_by_kdtidur($kode_tidur)->row_array();
		$this->load->view('auth/form_edittidur', $data);
	 }
	 public function aksi_edit_tidur(){
		$kode_tidur=$this->input->post('kode_tidur');
		$kategori_tidur=$this->input->post('kategori_tidur');
		$merk_tidur=$this->input->post('merk_tidur');
		$keterangan_tidur=$this->input->post('keterangan_tidur');
		$harga_tidur=$this->input->post('harga_tidur');
		$gambar_tidur=$_FILES['gambar_tidur'];
			$config['upload_path'] = './assets/upload';
			$config['allowed_types'] = 'jpg|png|gif';

			$this->load->library('upload', $config);

			if(!$this->upload->do_upload('gambar_tidur')){
				echo "Upload Gagal"; die();
			}else{
				$gambar_tidur=$this->upload->data('file_name');
			}
		


		$data=array(
		'kategori_tidur'=>$kategori_tidur,
		'merk_tidur'=>$merk_tidur,
		'keterangan_tidur'=>$keterangan_tidur,
		'harga_tidur'=>$harga_tidur,
		'gambar_tidur'=>$gambar_tidur,
		);
		$this->M_login->update_tidur($data,$kode_tidur);
	if($this->db->affected_rows()){
		redirect('auth/tidur');
	} else {
		redirect('auth/edit_tidur/'.$kode_tidur);
	}  
	}
	
	public function hapus_tidur($kode_tidur){
		$this->M_login->hapus_tidur($kode_tidur);
		if($this->db->affected_rows()){
			redirect('auth/tidur');
		} else {
			echo "Data gagal dihapus";
		} 
	
	}


//===============================================================
// FUNGSI UNTUK DATA PERLENGKAPAN BELAJAR

public function belajar(){
       
	$data['produk'] = $this->M_login->get_belajar()->result_array();
	$this->load->view('auth/main_belajar',$data);

}


public function tambah_belajar(){
	$this->load->view('auth/form_tambahbelajar');
}
public function aksi_simpan_belajar(){
	$kode_belajar=$this->input->post('kode_belajar');
	$kategori_belajar=$this->input->post('kategori_belajar');
	$merk_belajar=$this->input->post('merk_belajar');
	$keterangan_belajar=$this->input->post('keterangan_belajar');
	$harga_belajar=$this->input->post('harga_belajar');
	$gambar_belajar=$_FILES['gambar_belajar'];
				$config['upload_path']		= './assets/upload';
				$config['allowed_types'] 	= 'jpg|png|gif';

				$this->load->library('upload', $config);

				if(! $this->upload->do_upload('gambar_belajar')){
					echo "Upload Gagal"; die();
				}else{
					$gambar_belajar=$this->upload->data('file_name');
				}
			
	$data=array(
	'kode_belajar'=>$kode_belajar,
	'kategori_belajar'=>$kategori_belajar,
	'merk_belajar'=>$merk_belajar,
	'keterangan_belajar'=>$keterangan_belajar,
	'harga_belajar'=>$harga_belajar,
	'gambar_belajar'=>$gambar_belajar,
	);
	$this->M_login->insert_belajar($data);
if($this->db->affected_rows()){
	redirect('auth/belajar');
} else {
	redirect('auth/tambah_belajar');
}  
}

public function edit_belajar($kode_belajar){
	$data['produk'] = $this->M_login->get_data_by_kdbelajar($kode_belajar)->row_array();
	$this->load->view('auth/form_editbelajar', $data);
 }
 public function aksi_edit_belajar(){
	$kode_belajar=$this->input->post('kode_belajar');
	$kategori_belajar=$this->input->post('kategori_belajar');
	$merk_belajar=$this->input->post('merk_belajar');
	$keterangan_belajar=$this->input->post('keterangan_belajar');
	$harga_belajar=$this->input->post('Harga_belajar');
	$gambar_belajar=$this->input->post('gambar_belajar');
	$gambar_belajar=$_FILES['gambar_belajar'];
				$config['upload_path']		= './assets/upload';
				$config['allowed_types'] 	= 'jpg|png|gif';

				$this->load->library('upload', $config);

				if(! $this->upload->do_upload('gambar_belajar')){
					echo "Upload Gagal"; die();
				}else{
					$gambar_belajar=$this->upload->data('file_name');
				}
			

	$data=array(
	'kategori_belajar'=>$kategori_belajar,
	'merk_belajar'=>$merk_belajar,
	'keterangan_belajar'=>$keterangan_belajar,
	'harga_belajar'=>$harga_belajar,
	'gambar_belajar'=>$gambar_belajar,
	);
	$this->M_login->update_belajar($data,$kode_belajar);
if($this->db->affected_rows()){
	redirect('auth/belajar');
} else {
	redirect('auth/edit_belajar/'.$kode_belajar);
}  
}

public function hapus_belajar($kode_belajar){
	$this->M_login->hapus_belajar($kode_belajar);
	if($this->db->affected_rows()){
		redirect('auth/belajar');
	} else {
		echo "Data gagal dihapus";
	} 

}



//===============================================================
// FUNGSI UNTUK DATA PERLENGKAPAN elekteonik

public function elektronik(){
       
	$data['produk'] = $this->M_login->get_elektronik()->result_array();
	$this->load->view('auth/main_elektronik',$data);

}

public function tambah_elektronik(){
	$this->load->view('auth/form_tambahelektronik');
}
public function aksi_simpan_elektronik(){
	$kode_elektronik=$this->input->post('kode_elektronik');
	$kategori_elektronik=$this->input->post('kategori_elektronik');
	$merk_elektronik=$this->input->post('merk_elektronik');
	$keterangan_elektronik=$this->input->post('keterangan_elektronik');
	$harga_elektronik=$this->input->post('harga_elektronik');
	$gambar_elektronik=$_FILES['gambar_elektronik'];
		$config['upload_path']	= './assets/upload';
		$config['allowed_types'] = 'jpg|png|gif';

		$this->load->library('upload', $config);

		if(!$this->upload->do_upload('gambar_elektronik')){
			echo "Upload Gagal"; die();
		}else{
			$gambar_elektronik=$this->upload->data('file_name');
		}
	

	$data=array(
	'kode_elektronik'=>$kode_elektronik,
	'kategori_elektronik'=>$kategori_elektronik,
	'merk_elektronik'=>$merk_elektronik,
	'keterangan_elektronik'=>$keterangan_elektronik,
	'harga_elektronik'=>$harga_elektronik,
	'gambar_elektronik'=>$gambar_elektronik,
	);
	$this->M_login->insert_elektronik($data);
if($this->db->affected_rows()){
	redirect('auth/elektronik');
} else {
	redirect('auth/tambah_elektronik');
}  
}

public function edit_elektronik($kode_elektronik){
	$data['produk'] = $this->M_login->get_data_by_kdelektronik($kode_elektronik)->row_array();
	$this->load->view('auth/form_editelektronik', $data);
 }
 public function aksi_edit_elektronik(){
	$kode_elektronik=$this->input->post('kode_elektronik');
	$kategori_elektronik=$this->input->post('kategori_elektronik');
	$merk_elektronik=$this->input->post('merk_elektronik');
	$keterangan_elektronik=$this->input->post('keterangan_elektronik');
	$harga_elektronik=$this->input->post('harga_elektronik');
	$gambar_elektronik=$_FILES['gambar_elektronik'];
		$config['upload_path']	= './assets/upload';
		$config['allowed_types'] = 'jpg|png|gif';

		$this->load->library('upload', $config);

		if(!$this->upload->do_upload('gambar_elektronik')){
			echo "Upload Gagal"; die();
		}else{
			$gambar_elektronik=$this->upload->data('file_name');
		}
	


	$data=array(
	'kategori_elektronik'=>$kategori_elektronik,
	'merk_elektronik'=>$merk_elektronik,
	'keterangan_elektronik'=>$keterangan_elektronik,
	'harga_elektronik'=>$harga_elektronik,
	'gambar_elektronik'=>$gambar_elektronik,
	);
	$this->M_login->update_elektronik($data,$kode_elektronik);
if($this->db->affected_rows()){
	redirect('auth/elektronik');
} else {
	redirect('auth/edit_elektronik/'.$kode_elektronik);
}  
}

public function hapus_elektronik($kode_elektronik){
	$this->M_login->hapus_elektronik($kode_elektronik);
	if($this->db->affected_rows()){
		redirect('auth/elektronik');
	} else {
		echo "Data gagal dihapus";
	} 

}


//===============================================================
// FUNGSI UNTUK DATA PERLENGKAPAN Dapur

public function dapur(){
       
	$data['produk'] = $this->M_login->get_dapur()->result_array();
	$this->load->view('auth/main_dapur',$data);

}

public function tambah_dapur(){
	$this->load->view('auth/form_tambahdapur');
}
public function aksi_simpan_dapur(){
	$kode_dapur=$this->input->post('kode_dapur');
	$kategori_dapur=$this->input->post('kategori_dapur');
	$merk_dapur=$this->input->post('merk_dapur');
	$keterangan_dapur=$this->input->post('keterangan_dapur');
	$harga_dapur=$this->input->post('harga_dapur');
	$gambar_dapur=$_FILES['gambar_dapur'];
		$config['upload_path'] = './assets/upload';
		$config['allowed_types'] = 'jpg|png|gif';

		$this->load->library('upload', $config);

		if(! $this->upload->do_upload('gambar_dapur')){
			echo "Upload Gagal"; die();
		}else{
			$gambar_dapur=$this->upload->data('file_name');
		}
	

	$data=array(
	'kode_dapur'=>$kode_dapur,
	'kategori_dapur'=>$kategori_dapur,
	'merk_dapur'=>$merk_dapur,
	'keterangan_dapur'=>$keterangan_dapur,
	'harga_dapur'=>$harga_dapur,
	'gambar_dapur'=>$gambar_dapur,
	);
	$this->M_login->insert_dapur($data);
if($this->db->affected_rows()){
	redirect('auth/dapur');
} else {
	redirect('auth/tambah_dapur');
}  
}

public function edit_dapur($kode_dapur){
	$data['produk'] = $this->M_login->get_data_by_kddapur($kode_dapur)->row_array();
	$this->load->view('auth/form_editdapur', $data);
 }
 public function aksi_edit_dapur(){
	$kode_dapur=$this->input->post('kode_dapur');
	$kategori_dapur=$this->input->post('kategori_dapur');
	$merk_dapur=$this->input->post('merk_dapur');
	$keterangan_dapur=$this->input->post('keterangan_dapur');
	$harga_dapur=$this->input->post('harga_dapur');
	$gambar_dapur=$_FILES['gambar_dapur'];
		$config['upload_path'] = './assets/upload';
		$config['allowed_types'] = 'jpg|png|gif';

		$this->load->library('upload', $config);

		if (! $this->upload->do_upload('gambar_dapur')){
		}else{
			$gambar_dapur=$this->upload->data('file_name');
		}
	


	$data=array(
	'kode_dapur'=>$kode_dapur,
	'kategori_dapur'=>$kategori_dapur,
	'merk_dapur'=>$merk_dapur,
	'keterangan_dapur'=>$keterangan_dapur,
	'harga_dapur'=>$harga_dapur,
	'gambar_dapur'=>$gambar_dapur,
	);
	$this->M_login->update_dapur($data,$kode_dapur);
if($this->db->affected_rows()){
	redirect('auth/dapur');
} else {
	redirect('auth/edit_dapur/'.$kode_dapur);
}  
}

public function hapus_dapur($kode_dapur){
	$this->M_login->hapus_dapur($kode_dapur);
	if($this->db->affected_rows()){
		redirect('auth/dapur');
	} else {
		echo "Data gagal dihapus";
	} 

}



//===============================================================
// FUNGSI UNTUK DATA PERLENGKAPAN Mandi

public function mandi(){
       
	$data['produk'] = $this->M_login->get_mandi()->result_array();
	$this->load->view('auth/main_mandi',$data);

}

public function tambah_mandi(){
	$this->load->view('auth/form_tambahmandi');
}
public function aksi_simpan_mandi(){
	$kode_mandi=$this->input->post('kode_mandi');
	$kategori_mandi=$this->input->post('kategori_mandi');
	$merk_mandi=$this->input->post('merk_mandi');
	$keterangan_mandi=$this->input->post('keterangan_mandi');
	$harga_mandi=$this->input->post('harga_mandi');
	$gambar_mandi=$_FILES['gambar_mandi'];
			$config['upload_path'] = './assets/upload';
			$config['allowed_types'] = 'jpg|png|gif';

			$this->load->library('upload', $config);

			if(!$this->upload->do_upload('gambar_mandi')){
				echo "Upload Gagal"; die();
			}else{
				$gambar_mandi=$this->upload->data('file_name');
			}
		


	$data=array(
	'kode_mandi'=>$kode_mandi,
	'kategori_mandi'=>$kategori_mandi,
	'merk_mandi'=>$merk_mandi,
	'keterangan_mandi'=>$keterangan_mandi,
	'harga_mandi'=>$harga_mandi,
	'gambar_mandi'=>$gambar_mandi,
	);
	$this->M_login->insert_mandi($data);
if($this->db->affected_rows()){
	redirect('auth/mandi');
} else {
	redirect('auth/tambah_mandi');
}  
}

public function edit_mandi($kode_mandi){
	$data['produk'] = $this->M_login->get_data_by_kdmandi($kode_mandi)->row_array();
	$this->load->view('auth/form_editmandi', $data);
 }
 public function aksi_edit_mandi(){
	$kode_mandi=$this->input->post('kode_mandi');
	$kategori_mandi=$this->input->post('kategori_mandi');
	$merk_mandi=$this->input->post('merk_mandi');
	$keterangan_mandi=$this->input->post('keterangan_mandi');
	$harga_mandi=$this->input->post('harga_mandi');
	$gambar_mandi=$_FILES['gambar_mandi'];
			$config['upload_path'] = './assets/upload';
			$config['allowed_types'] = 'jpg|png|gif';

			$this->load->library('upload', $config);

			if(!$this->upload->do_upload('gambar_mandi')){
				echo "Upload Gagal"; die();
			}else{
				$gambar_mandi=$this->upload->data('file_name');
			}
		

	$data=array(
	'kode_mandi'=>$kode_mandi,
	'kategori_mandi'=>$kategori_mandi,
	'merk_mandi'=>$merk_mandi,
	'keterangan_mandi'=>$keterangan_mandi,
	'harga_mandi'=>$harga_mandi,
	'gambar_mandi'=>$gambar_mandi,
	);
	$this->M_login->update_mandi($data,$kode_mandi);
if($this->db->affected_rows()){
	redirect('auth/mandi');
} else {
	redirect('auth/edit_mandi/'.$kode_mandi);
}  
}

public function hapus_mandi($kode_mandi){
	$this->M_login->hapus_mandi($kode_mandi);
	if($this->db->affected_rows()){
		redirect('auth/mandi');
	} else {
		echo "Data gagal dihapus";
	} 
}

//Menampilkan data ke front end
public function utama(){
	$this->load->view('halaman_utama');
}

public function utama_belajar(){
	$data['produk'] = $this->M_login->get_belajar()->result_array();
	$this->load->view('halaman_belajar',$data);
}

public function utama_dapur(){
	$data['produk'] = $this->M_login->get_dapur()->result_array();
	$this->load->view('halaman_dapur',$data);
}

public function utama_elektronik(){
	$data['produk'] = $this->M_login->get_elektronik()->result_array();
	$this->load->view('halaman_elektronik',$data);
}

public function utama_mandi(){
	$data['produk'] = $this->M_login->get_mandi()->result_array();
	$this->load->view('halaman_mandi',$data);
}

public function utama_tidur(){
	$data['produk'] = $this->M_login->get_tidur()->result_array();
	$this->load->view('halaman_tidur',$data);
}










}

?>