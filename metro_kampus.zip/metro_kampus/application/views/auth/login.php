<!DOCTYPE html>
<html lang="en">

<head>
<link href="assets/css/csslogin.css" rel="stylesheet" type="text/css" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin Login</title>
</head>
<body>
    <div class="login">
    <div class="foto">
    <div class="header">
        <h1>Login Admin</h1>
        <h2>METRO KAMPUS</h2>
           </div>
                <form class="user" action="Auth/aksi_login" method="post">
                     <div class="form">
                        <img src="assets/img/metrologin.jpg">
                       <div class="usnpswd">
                       <input type="text" class="form-control form-control-user"
                         id="exampleInputEmail" name="username"
                          placeholder="Enter Username">
                        </div>
                        
                        <div class="usnpswd">
                        <input type="password" class="form-control form-control-user"
                         id="password" name="password" placeholder="Password">
                        </div>
                     </div>
                            <div class="submit">
                                <button type="submit" class="btn btn-primary btn-user btn-block"> Login</button>
                    
                            </div>
                </form>
</div>
    </div>  
</body>                      
</html>