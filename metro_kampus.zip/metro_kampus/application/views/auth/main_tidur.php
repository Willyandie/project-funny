<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300&display=swap"/>
    <title>Selamat datang user</title>
</head>
<style>

@import url("https://fonts.googleapis.com/css2?family=Comfortaa:wght@300&display=swap");

body {
    background-color: #FFF;
    font-family: Comfortaa;
    margin: 0;
    padding: 0;
}

.main {
    display: flex;
}
.header{
    height: 130px;
    width: auto;
    background-color: #ff9500; 
    margin-left: 150px;
    margin-top: -30px;
    font-family: Comfortaa;
}
.header h2{
    text-align: center;
    padding-top: 25px;
    font-family: Comfortaa;
    font-size: 30px;
    color:white;
}

.data1{	
            font-family: Comfortaa;
            font-size: large;
            z-index: 1;
            border-radius: 5px;
            max-width: 100%;
            margin-top:20px;
            margin-left: 200px;
            text-align: center;
            box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
    }

    .data1 h3 {
        color: #ff9500; 
        padding-top:30px;
    }

    .data1 #belajar tr:nth-child(even){background-color: #fff;}

    .data1 table{
        width:95%;
        margin-left:50px;
        padding: 30px;
    }

    .data1 #belajar tr:hover {background-color:#939B62; }

    .data1 #belajar th {
    padding-bottom: 12px;
    text-align: left;
    background-color: #ff9500;
    color: white;
    }

    .data1 #belajar tr th {
        text-align: center;
    }

.sidebar {
        width: 25vw;
        max-width: 250px;
        height: 100vh;
        list-style: none;
        background-color: #939B62;
        float:left;
        margin-top: -125px;
        margin-left: -20px;
        padding-top: 10px;
        padding-left: 30px;
        
        }
        .sidebar li a {
        display: block;
        padding-left: -25px;
        padding-top: 25px;
        padding-bottom: 30px;
        text-decoration: none;
        color: rgb(255, 255, 255);
        font-weight: bold;
        text-transform: uppercase;
        transition: 0.5s;
        padding-left: -5px;
        }
        .sidebar li a:hover {
        background-color:#ff9500; 
		padding:10px;
        }

        .sidebar h1 {
            color: white;
			font-size:40px;
        }
      

    </style>
<body>

<div class="header">
	<h2>Selamat Datang Admin</h2>
	</div>

 	<div class="side">
     <ul class="sidebar">
     <a href="utama"><li><h1>METRO KAMPUS</h1></li></a>
     <li><a href="belajar">Katalog Belajar</a></li>
    <li><a href="tidur">Katalog Tidur</a></li>
    <li><a href="dapur">Katalog Dapur</a></li>
    <li><a href="mandi">Katalog Mandi</a></li>
    <li><a href="elektronik">Katalog Elektronik</a></li>
    <li><a href="<?php echo site_url('auth');?>">Log Out</a></a></li>
  </ul>
    </div>

	<div class="data1">
    
    <h3>Halaman Tampil Data Barang Tidur</h3>
    <hr>
    <a href="<?php echo site_url('auth/tambah_tidur');?>">Tambah Data Barang Tidur</a>
    <?php
    $no = 1;
         ?>
    
    <table id="belajar">
        <tr>
            <th>No</th>
            <th>Kode</th>
            <th>Kategori</th>
            <th>Merk</th>
            <th>Keterangan</th>
            <th>Harga</th>
            <th>Gambar</th>
            <th>Kelola</th>
        </tr>
        <?php foreach($produk as $item){?>
            <tr>
                <td><?php echo $no;?></td>
                <td><?php echo $item['kode_tidur'];?></td>
                <td><?php echo $item['kategori_tidur'];?></td>
                <td><?php echo $item['merk_tidur'];?></td>
                <td><?php echo $item['keterangan_tidur'];?></td>
                <td><?php echo $item['harga_tidur'];?></td>
                <td>
                 <img src="<?php echo base_url();?>assets/upload/<?php echo
                 $item['gambar_tidur']; ?>" width="90" height="110";></td>
                 
                <td><a href="<?php echo site_url('auth/edit_tidur/'.$item['kode_tidur']);?>">Edit</a>
                <a href="<?php echo site_url('auth/hapus_tidur/'.$item['kode_tidur']);?>" onclick="return confirm('Apakah anda yakin hapus data ini?')">Hapus</a></td>
        </tr>
        
    <?php 
    $no++;
    }?>
    </table>
    </body>
    </div> 
    </html> 