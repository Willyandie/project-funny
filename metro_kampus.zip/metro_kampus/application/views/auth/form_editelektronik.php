<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300&display=swap"/>
    <title>Selamat datang user</title>
</head>
<style>

@import url("https://fonts.googleapis.com/css2?family=Comfortaa:wght@300&display=swap");

body {
    background-color: #FFF;
    font-family: Comfortaa;
    margin: 0;
    padding: 0;
}

.main {
    display: flex;
}
.header{
    height: 130px;
    width: auto;
    background-color: #ff9500; 
    margin-left: 150px;
    margin-top: -30px;
    font-family: Comfortaa;
}
.header h2{
    text-align: center;
    padding-top: 25px;
    font-family: Comfortaa;
    font-size: 30px;
    color:white;
}

.data1{	
            font-family: Comfortaa;
            font-size: large;
            z-index: 1;
            border-radius: 5px;
            max-width: 100%;
            margin-top:20px;
            margin-left: 200px;
    
            padding-bottom:50px;
            box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
    }

    .data1 h3 {
        color: #ff9500;
        text-align: center;
        padding-top:30px;
        
    }


    .form .kode input{
    position: left;
    width: 40%;
    padding: 10px 10px;
    font-size: 16px;
    color: black;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid orange;
    margin-left:80px;
    outline: none;
    font-family: Comfortaa;
}

    .form .kode{
        padding-left: 125px;
        padding-top:50px;
        width:1000px;
    }

.form .kategori input{
    position: left;
    width: 40%;
    padding: 10px 10px;
    font-size: 16px;
    color: black;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid orange;
    margin-left:130px;
    outline: none;
    font-family: Comfortaa;
}
.form .kategori{
        padding-left: 125px;
        width:1000px;
    }

.form .merk input{
    position: left;
    width: 40%;
    padding: 10px 10px;
    font-size: 16px;
    color: black;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid orange;
    margin-left:85px;
    outline: none;
    font-family: Comfortaa;
}
.form .merk{
        padding-left: 125px;
        width:1000px;
    }

.form .keterangan input{
    position: left;
    width: 40%;
    padding: 10px 10px;
    font-size: 16px;
    color: black;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid orange;
    margin-left:25px;
    outline: none;
    font-family: Comfortaa;
}
.form .keterangan{
        padding-left: 125px;
        width:1000px;
    }

.form .harga input{
    position: left;
    width: 40%;
    padding: 10px 10px;
    font-size: 16px;
    color: black;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid orange;
    margin-left:75px;
    outline: none;
    font-family: Comfortaa;
}
.form .harga{
        padding-left: 125px;
        width:1000px;
    }
    .form .gambar img{
    position: left;
    padding: 10px 10px;
    font-size: 16px;
    color: black;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid orange;
    margin-left:215px;
    outline: none;
    margin-top:-80px;
    font-family: Comfortaa;
    
}

.form .gambar input{
    padding-left:50px;
    margin-bottom:-50px;
   
}
.form .gambar{
        padding-left: 125px;
    }

.form .browse{
    padding-left:340px;
    padding-bottom:20px;
    margin-top:-25px;
}

.submit button {
    width:100px;
    height:40px;
    color: #ffffff;
    font-size: 15px;
    text-decoration: none;
    text-transform: uppercase;
    overflow: hidden;
    transition: .5s;
    letter-spacing: 4px;
    margin: auto;
    padding-left:10px;
    flex-direction: row;
    border: none;
    outline: none;
    background: orange;

}

.submit{
    padding-left:125px;

}

.sidebar {
        width: 25vw;
        max-width: 250px;
        height: 100vh;
        list-style: none;
        background-color: #939B62;
        float:left;
        margin-top: -125px;
        margin-left: -20px;
        padding-top: 10px;
        padding-left: 30px;
        
        }
        .sidebar li a {
        display: block;
        padding-left: -25px;
        padding-top: 25px;
        padding-bottom: 30px;
        text-decoration: none;
        color: rgb(255, 255, 255);
        font-weight: bold;
        text-transform: uppercase;
        transition: 0.5s;
        padding-left: -5px;
        }
        .sidebar li a:hover {
        background-color:#ff9500; 
		padding:10px;
        }

        .sidebar h1 {
            color: white;
			font-size:40px;
        }
      

    </style>
<body>

<div class="header">
	<h2>Selamat Datang Admin</h2>
	</div>

 	<div class="side">
     <ul class="sidebar">
     <a href="utama"><li><h1>METRO KAMPUS</h1></li></a>
    <li><a href="belajar">Katalog Belajar</a></li>
    <li><a href="tidur">Katalog Tidur</a></li>
    <li><a href="dapur">Katalog Dapur</a></li>
    <li><a href="mandi">Katalog Mandi</a></li>
    <li><a href="elektronik">Katalog Elektronik</a></li>
    <li><a href="<?php echo site_url('auth');?>">Log Out</a></a></li>
  </ul>
    </div>
	<div class="data1">
    
    <h3>Update Data Barang Elektronik</h3>
    <hr>
        <div class="form">
      <form action="<?php echo site_url('auth/aksi_edit_elektronik');?>"method="POST"  enctype="multipart/form-data">
    
            
              
                <input type="hidden" name="kode_elektronik" value="<?php echo $produk['kode_elektronik'];?>">

                <div class="kategori">
                Kategori<input type="text" name="kategori_elektronik" value="<?php echo $produk['kategori_elektronik'];?>">
                </div>

                <div class="merk">
                <td>Merk barang <input type="text" name="merk_elektronik" value="<?php echo $produk['merk_elektronik'];?>">
                </div>

                <div class="keterangan">
                <td>Keterangan barang <input type="text" name="keterangan_elektronik" value="<?php echo $produk['keterangan_elektronik'];?>">
                </div>

                <div class="harga">
                <td>Harga barang <input type="text" name="harga_elektronik" value="<?php echo $produk['harga_elektronik'];?>">
                </div>

                <div class="gambar">
                    <p>Gambar</p><img src="<?php echo base_url();?>assets/upload/<?php echo $produk['gambar_elektronik'];?>" width="90" height="110";>
                </div>
                      
                <div class="browse">
                        <input type="file" name="gambar_elektronik" value="<?php echo $produk['gambar_elektronik'];?>">
                </div>

                    <div class="submit">
                    <button type="submit" value="Simpan">Simpan</buttton>
                    <button type="reset" value="Batal">Batal</button>
    </div>
    </div>
	</body>