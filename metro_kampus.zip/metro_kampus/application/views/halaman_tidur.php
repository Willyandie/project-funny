<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Metro Kampus xixixi</title>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300&display=swap"/>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Comfortaa:wght@300&display=swap");
        .header{
            background-color:#FF8B13;
            text-align:center;
            padding:30px;
        }

        .header h1{
            color:white;
            background-color:#FF8B13;
        }

        body,* {
   font-family: Comfortaa;
   background-color:#FFB26B;
}
nav {
   width: 100%;
   height: 100px;
   background-color:#FF8B13;
}
nav ul {
   margin: 0;
   padding: 0;
   background-color:#FF8B13;
}
nav ul li {
   list-style-type: none;
   display: inline-block;
   float: center;
   line-height: 100px;
   padding-right:30px;
   background-color:#FF8B13;
}
nav ul li a {
   text-decoration: none;
   margin: 5px;
   padding: 14px 20px;
   color: white;
   font-size:20px;
   background-color:#FF8B13;
}
nav ul li a:hover {
   color : #fff;
   background-color: #939B62;
}

.belajar {
    background-color:#FFD56F;
    width:900px;
    margin-left:600px;
    margin-top:40px;
    padding:20px;
}

.belajar img{
    border-radius:10px;
    background-color:#FFD56F;
    margin-left:50px;
}

.belajar a{
    color:white;
    background-color:#FFD56F;
    font-size:20px;
}

.footer{
    background-color:white;
    margin-top:40px;
    padding-left:900px;
}

.footer img{
    background-color:white;
}

    </style>

</head>
<body>
        <div class="header">
     <h1>METRO KAMPUS</h1>
     <nav>
   <ul>
   <li><a href="utama">Home</a></li>
     <li><a href="utama_belajar">Perlengkapan Belajar</a></li>
     <li><a href="utama_tidur">Perlengkapan Tidur</a></li>
     <li><a href="utama_dapur">Perlengkapan Dapur</a></li>
     <li><a href="utama_mandi">Perlengkapan Mandi</a></li>
     <li><a href="utama_elektronik">Perlengkapan Elektronik</a></li>
   </ul>
   </nav>
</div>
<?php foreach($produk as $item){?>
        <div class="belajar">
           <img src="<?php echo base_url(); ?>assets/upload/<?php echo $item['gambar_tidur']; ?> "width= "800" height="800";> <br>
                <a>Merek :<?php echo $item['merk_tidur'];?><br>
               <a>Kategori : <?php echo $item['kategori_tidur'];?><br>
                <a>Keterangan :<?php echo $item['keterangan_tidur'];?><br>
                <a>Harga :<?php echo $item['harga_tidur'];?>
                <hr>
     
    </div>
     <?php 
     }?>

     <div class="footer">
        <img src="../assets/img/Facebook.png" widht="75px" height="75px">
        <img src="../assets/img/Instagram.png" widht="75px" height="75px">
        <img src="../assets/img/Tik Tok.png" widht="75px" height="75px">
        <img src="../assets/img/Whatsapp.png" widht="75px" height="75px">
    </div>
</body>
</html>