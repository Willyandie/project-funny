<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Metro Kampus xixixi</title>
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300&display=swap"/>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Comfortaa:wght@300&display=swap");
        .header{
            background-color:#FF8B13;
            text-align:center;
            padding:30px;
        }

        .header h1{
            color:white;

            background-color:#FF8B13;
        }

        body,* {
        font-family: Comfortaa;
        background-color:#FFB26B;
        }

nav {
   width: 100%;
   height: 100px;
   background-color:#FF8B13;
}

nav ul {
   margin: 0;
   padding: 0;
   background-color:#FF8B13;
}

nav ul li {
   list-style-type: none;
   display: inline-block;
   float: center;
   line-height: 100px;
   padding-right:30px;
   background-color:#FF8B13;
}

nav ul li a {
   text-decoration: none;
   margin: 5px;
   padding: 14px 20px;
   color: white;
   font-size:20px;
   background-color:#FF8B13;
}

nav ul li a:hover {
   color : #fff;
   background-color: #939B62;
}

.footer{
    background-color:white;
    margin-top:300px;
    padding-left:900px;
}

.footer img{
    background-color:white;
}

.profile {
    color:white;
    padding-left:50px;
}

.profile h1 {
    font-size:50px;
}

.profile p {
    font-size:30px;
}

.profile img {
    width: 600px;
    height: 600px;
    float: left;
    margin-top: -134px;
    margin-left: 50px;
    margin-top:30px;
    padding-top:-50px;
    padding-right:50px;
    border-radius: 15px 15px;
}

.profile li {
    font-size:20px;
    padding:10px;
}

    </style>

</head>
<body>
        <div class="header">
     <h1>METRO KAMPUS</h1>
     <nav>
   <ul>
   <li><a href="utama">Home</a></li>
     <li><a href="utama_belajar">Perlengkapan Belajar</a></li>
     <li><a href="utama_tidur">Perlengkapan Tidur</a></li>
     <li><a href="utama_dapur">Perlengkapan Dapur</a></li>
     <li><a href="utama_mandi">Perlengkapan Mandi</a></li>
     <li><a href="utama_elektronik">Perlengkapan Elektronik</a></li>
   </ul>
   </nav>
</div>

<div class="profile">
    <img src="../assets/img/metrologin.jpg" width="">
<h1>ABOUT US</h1>

<p>Metro Kampus adalah Toko yang menjual kebutuhan kost, peralatan rumah tangga, perlengkapan kantor dan lain-lain.
Toko yang terkenal dengan harganya yang relatif murah dengan mengutamakan kualitas. Selain mahasiswa, tempat ini juga menjadi rekomendasi
para ibu rumah tangga yang ingin belanja murah perabot kamar, rumah dan lain sebagainya.</p>
<p>METRO KAMPUS Berdiri sejak 1 Maret 2014, sampai sekarang sudah memiliki 5 cabang di yogyakarta : </p>
<ol>
    <li>METRO KAMPUS UMS : Jalan Duwet Raya, Gonilan, Kartosura (Arah fak.Kedokteran UMS)</li>
    <li>METRO KAMPUS UNS : Jalan Raya Solo-Karanganyar (Belakang Kampus UNS)</li>
    <li>METRO KAMPUS UII : Depan kampus UII Jogjakarta</li>
    <li>METRO KAMPUS BABARSARI : Jl. Babarsari No.5 Yarada IV, depok, Sleman, Yogyakarta</li>
    <li>METRO KAMPUS UMY : Jl. Garuda, Kasihan, Bnatul, Yogyakarta (Belakang indomaret UMY)</li>
</ol>
</div>

     <div class="footer">
        <img src="../assets/img/Facebook.png" widht="75px" height="75px">
        <img src="../assets/img/Instagram.png" widht="75px" height="75px">
        <img src="../assets/img/Tik Tok.png" widht="75px" height="75px">
        <img src="../assets/img/Whatsapp.png" widht="75px" height="75px">
    </div>
</body>
</html>